<form action= "savegangguan.php" method="post">
<table width="80%" border="1" align="center" bgcolor="#FFFFFF">
  <tr>
    <th colspan="2" scope="col">ENTRY PENYAKIT </th>
  </tr>
  <tr>
    <td width="20%">Id Penyakit </td>
    <td width="179"><label>
    <input name="a" type="text" id="a" required >
    </label></td>
  </tr>
  <tr>
    <td>Nama Penyakit </td>
    <td><label>
    <input name="b" type="text" id="b" size="50" required>
</label></td>
  </tr>
 
  <tr>
    <td colspan="2"><label>
        <div align="right">
          <input type="submit" name="Submit" value="Simpan" />
        </div>
      </label></td>
  </tr>
</table> 
</form>

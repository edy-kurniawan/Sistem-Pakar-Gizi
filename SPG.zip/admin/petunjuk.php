<p>Bagi pasien lama tidak perlu lagi untuk melakukan registrasi. Cukup dengan memasukan id pasien pada kolom yang sudah ditentukan.</p>
<p>Bagi pasien baru, lakukan registrasi terlebih dahulu. </p>

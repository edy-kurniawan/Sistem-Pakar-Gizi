<form action= "savesolusi.php" method="post">
<table width="80%" border="1" align="center" bgcolor="#FFFFFF">
  <tr>
    <th colspan="2" scope="col">ENTRY SOLUSI</th>
  </tr>
  <tr>
    <td width="20%">Id Solusi</td>
    <td width="179"><label>
    <input name="a" type="text" id="a" required >
    </label></td>
  </tr>
  <tr>
    <td bordercolor="#000000" valign="top">Keterangan </td>
    <td bordercolor="#000000"><label>
    <textarea name="c" cols="70" rows="5" id="c" required="required"></textarea>
</label></td>
  </tr>
  <tr>
    <td colspan="2"><label>
        <div align="right">
          <input type="submit" name="Submit" value="Simpan" />
        </div>
      </label></td>
  </tr>
</table> 
</form>

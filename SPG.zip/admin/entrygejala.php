<form action= "savegejala.php" method="post">
<table width="80%" border="1" align="center" bgcolor="#FFFFFF">
  <tr>
    <th colspan="2" scope="col">ENTRY GEJALA</th>
  </tr>
  <tr>
    <td width="20%">Id Gejala</td>
    <td width="179"><label>
    <input name="a" type="text" id="a" required >
    </label></td>
  </tr>
  <tr>
    <td bordercolor="#000000">Nama Gejala </td>
    <td bordercolor="#000000"><label>
    <input name="c" type="text" id="c" size="100" required>
</label></td>
  </tr>
  <tr>
    <td colspan="2"><label>
        <div align="right">
          <input type="submit" name="Submit" value="Simpan" />
        </div>
      </label></td>
  </tr>
</table> 
</form>

<table width="60%">
  <tr>
    <td><strong>&gt;&gt; Pasien Lama </strong></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>Id  Pasien </td>
    <td><form name="form1" method="post" action="caripasien.php">
      <label>
        <input name="cari" type="text" id="cari">
        </label>
      <label>
      <input type="submit" name="Submit" value="Konsultasi">
      </label>
    </form>
    </td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><strong>&gt;&gt; Pasien Baru </strong></td>
    <td><? echo "<a href='index.php?mod=regis'><input type=button class='btn btn-green' value=Registrasi></a> "; ?></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table>
